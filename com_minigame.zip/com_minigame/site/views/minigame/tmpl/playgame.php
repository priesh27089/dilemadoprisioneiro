<? // no direct access
defined( '_JEXEC' ) or die( 'Restricted access'); 

//check first if user is loged in
if(JFactory::getUser()->id > 0){
	
// JAVASCRIPT
	$document = &JFactory::getDocument();
	$document->addScriptDeclaration('
		var n_rounds = '.$this->mini_game->n_rounds.';
		var round_now = 0;
		var game_list = new Array();
		var player_score = 0;
		var player_name = "'. $this->player_name . '";
		var player_id = "' . $this->player_id . '";
		var perc = 0;
		
		function save_answer(){
			var answer = "";
		  
			// devolve a resposta do Jogador
			if(document.getElementById("answer_coop").checked){
				var answer = document.getElementById("answer_coop").value;
			}else if(document.getElementById("answer_defe").checked){
				var answer = document.getElementById("answer_defe").value;
			}
			
			if(answer != ""){
				var aux = "";
				// devolve a resposta do Adversário
				var opp_answer = getOpponentAnswer();
				// calcula e actualiza o array de pontos dos dois jogadores
				var player_points = getPlayerPoints(answer, opp_answer);
				var opp_points = getOpponentPoints(answer, opp_answer);
				//aux = "'.JText::_($this->mini_game->message_moves).'\n'.JText::_($this->player_name).': "+answer+" : "+player_points+"\n'.JText::_($this->opponent->name).': "+opp_answer+" : "+opp_points;
				//alert (aux);
				var round_n_aux = round_now+1;
				aux = "";
				if (round_now%2 == 0){
					aux += "<div id=\"history_odd\"><p class=\"textcenter\"><b>'.JText::_("Jogada ").'"+round_n_aux+"</b></p>";
				}else{
					aux = "<div id=\"history_even\"><p class=\"textcenter\"><b>'.JText::_("Jogada ").'"+round_n_aux+"</b></p>"; 	
				}
				aux += "<p><b>'.JText::_($this->player_name).'</b></p><p>'.JText::_("Acção: ").'"+answer+"</p><p>'.JText::_("Ganho: ").'"+player_points+"</p><p><b>'.JText::_($this->opponent->name).'</b></p><p>'.JText::_("Acção: ").'"+opp_answer+"</p><p>'.JText::_("Ganho: ").'"+opp_points+"</p></div>"; 
				document.getElementById("history").innerHTML = aux+document.getElementById("history").innerHTML;
				
				// deveria gravar os pontos no array
				saveScoreToArray(answer, player_points, opp_answer, opp_points);
				document.getElementById("div_points").innerHTML = "Score: "+player_score;
				perc = (player_score * 100)/('.$this->payofftable->player_3.' * '.$this->mini_game->n_rounds.');
				if(perc <=0) { perc = 0}
				document.getElementById("stars_game").style.width = perc+"%";
				
				updateRoundNumber();
				// verificar se era a ultima ronda
				if(round_now == n_rounds){
					Stop();
					//var bd_save_status = saveGame();
					// terminar jogo
					if(perc >= '.$this->mini_game->target_points_perc.'){
						alert("'.JText::_($this->mini_game->message_win).'");
					}else{
						alert("'.JText::_($this->mini_game->message_lose).'");
					}
					document.getElementById("button_save_answer").style.display = "none";
					document.getElementById("save_btn").style.display = "block";
				}
			}else{
				alert("Escolha uma jogada!");	
			}
		}
		
		function updateRoundNumber(){
			round_now++;
			document.getElementById("rounds").innerHTML = round_now+"/"+n_rounds;
			
		}
		
		function getOpponentAnswer(){
			var aux = "";
			var strategy = "'.$this->strategy->code.'"
			if( strategy == "cooperate" ){
				aux = "'.JText::_($this->payofftable->coop_txt).'";
			}else if( strategy == "defect" ){
				aux = "'.JText::_($this->payofftable->defe_txt).'";
				}else if( strategy == "random" ){
					var rr = Math.random();
					// r é a probabilidade de cooperar
					var r = "'.JText::_($this->strategy->variable).'";
					if(rr <= r){
						aux = "'.JText::_($this->payofftable->coop_txt).'";
					}else{
						aux = "'.JText::_($this->payofftable->defe_txt).'";
					}
				}else if( strategy == "titfortat"){
						if(round_now == 0){
							aux = "'.JText::_($this->payofftable->coop_txt).'";
						}else{
							var i = round_now - 1;
							aux = game_list[i][0];
						}
				}else{
					var r = Math.random();
					if(r >= 0.5){
						aux = "'.JText::_($this->payofftable->coop_txt).'";
					}else{
						aux = "'.JText::_($this->payofftable->defe_txt).'";
					}
				}
		return aux;
		}
		
		function getPlayerPoints(player_answer, opp_answer){
			var aux = "";
			
			if(player_answer == "'.JText::_($this->payofftable->coop_txt).'" && opp_answer == "'.JText::_($this->payofftable->coop_txt).'"){
				// os dois cooperam
				aux = '.JText::_($this->payofftable->player_1).';
			}else if(player_answer == "'.JText::_($this->payofftable->defe_txt).'" && opp_answer == "'.JText::_($this->payofftable->defe_txt).'"){
				// nenhum coopera
				aux = '.JText::_($this->payofftable->player_4).';
			}else if(player_answer == "'.JText::_($this->payofftable->coop_txt).'" && opp_answer == "'.JText::_($this->payofftable->defe_txt).'"){
				// jogador coopera mas adversario nao
				aux = '.JText::_($this->payofftable->player_2).';
			}else{
				// jogador nao coopera e adversario coopera
				aux = '.JText::_($this->payofftable->player_3).';
				}
			player_score = Number(player_score) + Number(aux);
			return aux;
		}
		
		function getOpponentPoints(player_answer, opp_answer){
			var aux = "";
			
			if(player_answer == "'.JText::_($this->payofftable->coop_txt).'" && opp_answer == "'.JText::_($this->payofftable->coop_txt).'"){
				// os dois cooperam
				aux = '.JText::_($this->payofftable->opponent_1).';
			}else if(player_answer == "'.JText::_($this->payofftable->defe_txt).'" && opp_answer == "'.JText::_($this->payofftable->defe_txt).'"){
				// nenhum coopera
				aux = '.JText::_($this->payofftable->opponent_4).';
			}else if(player_answer == "'.JText::_($this->payofftable->coop_txt).'" && opp_answer == "'.JText::_($this->payofftable->defe_txt).'"){
				// jogador coopera mas adversario nao
				aux = '.JText::_($this->payofftable->opponent_2).';
			}else{
				// jogador nao coopera e adversario coopera
				aux = '.JText::_($this->payofftable->opponent_3).';
				}
			return aux;
		}
		
		function saveScoreToArray(player_move, player_points, opp_move, opp_points){
			var move = new Array();
			move[0] = player_move;
			move[1] = player_points;
			move[2] = opp_move;
			move[3] = opp_points;
			game_list[round_now] = move;
		}
		
		function saveGame(){
			var game_id = "'.$this->mini_game->id_mini_game.'";
			var player_id = "'. $this->player_id .'";
			var theme_id = "'. $this->mini_game->id_theme .'";
			var time = document.getElementById("timetextarea").innerHTML;
			var opp_id = "'.$this->opponent->id_opponent.'";
			var data = "action=save_game&theme_id="+theme_id+"&game_id="+game_id+"&player_id="+player_id+"&opp_id="+opp_id+"&round_n="+n_rounds+"&time="+time;
			for(var i = 0; i < n_rounds;i++){
				data += "&round"+i+"="+i+"&player_move"+i+"="+game_list[i][0]+"&player_payoff"+i+"="+game_list[i][1]+"&opp_move"+i+"="+game_list[i][2]+"&opp_payoff"+i+"="+game_list[i][3];
			}
			
			var xmlhttp;
			if (window.XMLHttpRequest)
			{// code for IE7+, Firefox, Chrome, Opera, Safari
				xmlhttp=new XMLHttpRequest();
			}else
			{// code for IE6, IE5
				xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
			}
			xmlhttp.onreadystatechange=function()
			{
			if (xmlhttp.readyState==4 && xmlhttp.status==200)
				{
					var resp = xmlhttp.responseText;
					alert(resp);
					if(resp == "0"){
						alert("Jogo Gravado!");
						document.getElementById("save_btn").style.display = "none";
					}else{
						alert("Occoreu um erro na Base de Dados. Não foi possível gravar o seu Jogo, por favor contacte o Administrador.");
					}
				}
			}
			xmlhttp.open("POST","./components/com_minigame/codigo/save_game.php",true);
			xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
			xmlhttp.send(data);
		}
		
		var timercount = 0;
		var timestart  = null;
		 
		function showtimer() {
			if(timercount) {
				clearTimeout(timercount);
				clockID = 0;
			}
			if(!timestart){
				timestart = new Date();
			}
			var timeend = new Date();
			var timedifference = timeend.getTime() - timestart.getTime();
			timeend.setTime(timedifference);
			var minutes_passed = timeend.getMinutes();
			if(minutes_passed < 10){
				minutes_passed = "0" + minutes_passed;
			}
			var seconds_passed = timeend.getSeconds();
			if(seconds_passed < 10){
				seconds_passed = "0" + seconds_passed;
			}
			document.getElementById("timetextarea").innerHTML = minutes_passed + ":" + seconds_passed;
			timercount = setTimeout("showtimer()", 1000);
		}
		 
		function sw_start(){
			if(!timercount){
			timestart = new Date();
			document.getElementById("timetextarea").innerHTML = "00:00";
			timercount  = setTimeout("showtimer()", 1000);
			}
			else{
				var timeend = new Date();
				var timedifference = timeend.getTime() - timestart.getTime();
				timeend.setTime(timedifference);
				var minutes_passed = timeend.getMinutes();
				if(minutes_passed < 10){
					minutes_passed = "0" + minutes_passed;
				}
				var seconds_passed = timeend.getSeconds();
				if(seconds_passed < 10){
					seconds_passed = "0" + seconds_passed;
				}
			}
		}
		 
		function Stop() {
			if(timercount) {
				clearTimeout(timercount);
				timercount  = 0;
				var timeend = new Date();
				var timedifference = timeend.getTime() - timestart.getTime();
				timeend.setTime(timedifference);   
				var minutes_passed = timeend.getMinutes();
				if(minutes_passed < 10){
					minutes_passed = "0" + minutes_passed;
				}
				var seconds_passed = timeend.getSeconds();
				if(seconds_passed < 10){
					seconds_passed = "0" + seconds_passed;
				}
				document.getElementById("timetextarea").innerHTML = minutes_passed + ":" + seconds_passed;
			}
			timestart = null;
		}
	');

	$rootpath = JURI::root();
	echo '<form name="game_form" action="#" method="post">';
	echo '<div id="div_master">';
	
	echo '<div id="div_game_buttons">';
	echo '<a id="button" class="left" href="index.php?option=com_minigame&controller=minigame&task=list_minigames&id='.$this->mini_game->id_theme.'">'. JText::_("Sair") .'</a><br />';
	echo '<a id="button" class="left" href="index.php?option=com_minigame&controller=minigame&task=showgameintro&id='. $this->id_mini_game .'" target="_blank">'. JText::_("Introdução") .'</a><br />';
	if($this->mini_game->show_payoff_table == 1) { echo '<a id="button" class="left" href="index.php?option=com_minigame&controller=minigame&task=showpayofftable&id='.$this->id_mini_game.'" target="_blank">'. JText::_("Tabela de Ganhos") .'</a><br />'; } 
	echo '<a id="button" class="left" href="index.php?option=com_minigame&controller=minigame&task=showopponent&id='. $this->id_mini_game .'" target="_blank">'. JText::_("O Adversário"). '</a><br />';
	echo '<a id="button" class="left" href="index.php?option=com_minigame&controller=minigame&task=showtop10&id='. $this->id_mini_game .'" target="_blank">'.JText::_("Top 10"). '</a><br />';
	echo '<a id="save_btn" class="left button2" onclick="saveGame()">'.JText::_("Gravar"). '</a><br />';
	echo '</div>';
	
	echo '<div id="game_box3" style="background-image:url(' . $rootpath . 'images/stories/' . $this->media_image->folder_root . $this->media_image->file_name.')">';
	
	echo '<div id="score_panel">';
	echo '<div id="div_n_rounds">';
	echo '<div id="timetextarea">00:00</div>';
	echo '<div id="div_points">Score: 0</div>';
	echo '<div id="div_stars_game">';
	echo '<div id="stars_game"><img class="star2" src="'.$rootpath . 'images/stories/' . $this->stars->folder_root . $this->stars->file_name.'" /></div>';
	echo '</div>';
	echo '<div id="rounds">0/'.$this->mini_game->n_rounds.'</div>';
	echo '</div>';
	echo '<div id="history"></div>';
	echo '</div>';
	
	echo '<div id="opponent_image_txt2">';
	echo '<p class="game_txt2">'. JText::_($this->opponent->name) .'</p>';
	echo '<img id="opponent_image" src="' . $rootpath . 'images/stories/'.$this->opponent->folder_root.$this->opponent->file_name.'" width="156px" height="156px">';
	echo '</div>';
	
	
	echo '<div id="question">';
	echo '<p id="question_txt" class="game_txt">'.JText::_($this->mini_game->question).'</p>';
	echo '<p id="answer_player_coop_txt"><input name="answer" id="answer_coop" type="radio" value="'.JText::_($this->payofftable->coop_txt).'" />'.JText::_($this->payofftable->coop_txt).'</p>';
	echo '<p id="answer_player_defe_txt"><input name="answer" id="answer_defe" type="radio" value="'.JText::_($this->payofftable->defe_txt).'" />'.JText::_($this->payofftable->defe_txt).'</p>';
	echo '<p><a id="button_save_answer" class="left button2" href="#" onClick="save_answer()">Ok</a></p>';
	echo '</div>';
	echo '</div>';
	
	echo '<div id="hide_game_id" class="hide">'.$this->mini_game->id_mini_game.'</div>';
	echo '<div id="hide_intro_txt" class="hide">'.JText::_($this->mini_game->intro_txt).'</div>';
	echo '<div id="hide_bg_image" class="hide">'.JText::_($this->media_image->file_name).'</div>';
	echo '<div id="opponent_coop_txt" class="hide">'.JText::_($this->payofftable->coop_txt).'</div>';
	echo '<div id="opponent_defe_txt" class="hide">'.JText::_($this->payofftable->defe_txt).'</div>';
	echo '<div id="opponent_id" class="hide">'.$this->opponent->id_opponent.'</div>';
	echo '<div id="opponent_name" class="hide">'.JText::_($this->opponent->opponent_name).'</div>';
	echo '<div id="opponent_strategy" class="hide">'.$this->strategy->code.'</div>';
	echo '<div id="opponent_strategy_aux" class="hide">'.$this->strategy->variable.'</div>';
	echo '<div id="player_coop_txt" class="hide">'.JText::_($this->payofftable->coop_txt).'</div>';
	echo '<div id="player_defe_txt" class="hide">'.JText::_($this->payofftable->defe_txt).'</div>';
	echo '<div id="payoff_player1" class="hide">'.$this->payofftable->player_1.'</div>';
	echo '<div id="payoff_player2" class="hide">'.$this->payofftable->player_2.'</div>';
	echo '<div id="payoff_player3" class="hide">'.$this->payofftable->player_3.'</div>';
	echo '<div id="payoff_player4" class="hide">'.$this->payofftable->player_4.'</div>';
	echo '<div id="payoff_opponent1" class="hide">'.$this->payofftable->opponent_1.'</div>';
	echo '<div id="payoff_opponent2" class="hide">'.$this->payofftable->opponent_2.'</div>';
	echo '<div id="payoff_opponent3" class="hide">'.$this->payofftable->opponent_3.'</div>';
	echo '<div id="payoff_opponent4" class="hide">'.$this->payofftable->opponent_4.'</div>';
	
	echo '</div>';
	echo '</form>';
	
	echo '<script>';
	echo 'window.onload=sw_start();';
	echo '</script>';

}

?>