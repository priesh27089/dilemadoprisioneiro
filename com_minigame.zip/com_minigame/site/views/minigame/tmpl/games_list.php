<?php // no direct access
defined( '_JEXEC' ) or die( 'Restricted access'); 

//check first if user is loged in
if(JFactory::getUser()->id > 0){
	echo "<b>".JText::_(' Tema: ')."</b>".$this->theme_name."<br /><br />";
	echo  $this->games;
}
?>