<?php

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.view' );

class MinigameViewMinigame extends JView
{
	/**
	 * display method of Minigame view
	 **/
	 
	function display($tpl = null)
	{
		JHTML::stylesheet('dilemma.css', JURI::root().'components/com_minigame/codigo/' );
		//variables
		$this->assignRef('layout', JRequest::getVar( 'layout'));
		
		//theme list
		$themes = "";
		$db =& JFactory::getDBO();
		$sql = 'SELECT *' . ' FROM #__theme where active = 1';
      	$db->setQuery($sql);
		$rows = $db->loadObjectList();
		foreach($rows as $row){
			$themes .= "<a href=\"".JRoute::_( 'index.php?option=com_minigame&controller=minigame&task=list_minigames&id='. $row->id_theme )."\">".$row->name."</a><br />";
		}
		$this->assignRef('themes', $themes);
		
		
		// change layout?
		if($this->layout == 'games_list')
		{
			$this->list_minigames();
		}
		
		if($this->layout == 'playgame')
		{
			$this->playgame();
		}
		
		if($this->layout == 'info')
		{
			if(JRequest::getVar('info') == 'showgameintro')
			{
				$this->showgameintro();
			} 
			if(JRequest::getVar('info') == 'showpayofftable')
			{
				$this->showpayofftable();
			}
			if(JRequest::getVar('info') == 'showopponent')
			{
				$this->showopponent();
			}
			if(JRequest::getVar('info') == 'showtop10')
			{
				$this->showtop10();
			}
		}
		
		parent::display($tpl);
	}
	
	// Method to get game lists of the theme selected
	function list_minigames()
	{
		//variables
		$id_player = JFactory::getUser()->id;
		$this->assignRef('id_theme', JRequest::getVar( 'id_theme'));
		$rootpath = JURI::root();
		$output = "";
		$play_next_game = false;
		
		//theme
		$db =& JFactory::getDBO();
		$sql = 'SELECT * FROM #__theme WHERE id_theme = ' . $this->id_theme;
      	$db->setQuery($sql);
		$theme = $db->loadObject();
		$this->assignRef('theme_name', $theme->name);
		
		//theme media
		$sql = 'SELECT * FROM #__thememedia WHERE id_theme = ' . $this->id_theme;
      	$db->setQuery($sql);
		$thememedia = $db->loadObject();
		$this->assignRef('thememedia', $thememedia);
		
		
		// todos os Jogos
		$sql = 'SELECT * from #__minigame WHERE id_theme = ' . $this->id_theme . ' and active = 1 order by position asc';
		$db->setQuery($sql);
		$games = $db->loadObjectList();
		
		// primeiro jogo
		$sql = 'SELECT id_mini_game, min(position) from #__minigame where id_theme = ' . $this->id_theme . ' and active = 1';
		$db->setQuery($sql);
		$first = $db->loadObject();
		$output .='<div id="theme_bg" style="background-image: url('.$rootpath . 'images/stories/' . $thememedia->folder_root . $thememedia->file_name.')">';
		$output .='<p id="intro_theme_p">' . $theme->intro_txt . '</p>';
		$output .='<div id="div_games">';
		$output .='<table id="games"><tr><th>'.JText::_(' Nome ').'</th><th>'.JText::_(' Pontos ').'</th><th> </th></tr>';
		
		foreach($games as $game){
			
			// já jogou antes?
			$sql = 'SELECT id_mini_game, max(points) as points FROM (SELECT id_mini_game, sum(player_payoff) as points from #__move where id_mini_game = ' . $game->id_mini_game .' and id_user = '. $id_player .' GROUP BY id_theme, id_mini_game, date) A';
			$db->setQuery($sql);
			$repeat = $db->loadObject();
			
			//payoff table
			$sql = 'SELECT player_3 FROM #__minigame, #__payofftable WHERE #__minigame.id_payoff_table = #__payofftable.id_payoff_table and id_mini_game = ' . $game->id_mini_game;
			$db->setQuery($sql);
			$payofftable = $db->loadObject();
			
			$sql = 'SELECT * FROM #__minigamemedia WHERE id_mini_game = ' . $game->id_mini_game .' AND goal = "stars"';
			$db->setQuery($sql);
			$media = $db->loadObject();
			
			$percentagem = ($repeat->points / ($payofftable->player_3 * $game->n_rounds));
			
			if($game->id_mini_game == $repeat->id_mini_game)
			{
				$output .= "<tr><td><a href=\"".JRoute::_( 'index.php?option=com_minigame&controller=minigame&task=play_game&id='. $game->id_mini_game )."\">".$game->name."</a></td><td>".intval($repeat->points)."</td><td><div style=\"width: ".($percentagem * 100)."%; overflow-x: hidden; height: 30px;\"><img class=\"star1\" src=\"".$rootpath . 'images/stories/' . $media->folder_root . $media->file_name."\" /></div></td></tr>";
				
				if($percentagem < $game->target_points_perc)
				{
					$play_next_game = false;
				}else{
					$play_next_game = true;
				}
			}else{ 
				if($game->id_mini_game == $first->id_mini_game)
				{
					$output .= "<tr><td><a href=\"".JRoute::_( 'index.php?option=com_minigame&controller=minigame&task=play_game&id='. $game->id_mini_game )."\">".$game->name."</a></td><td>".intval($repeat->points)."</td><td><div style=\"width: 0%; overflow-x: hidden; height: 30px;\"><img class=\"star1\" src=\"".$rootpath . 'images/stories/' . $media->folder_root . $media->file_name."\" /></div></td></tr>";
				}else{
					if($play_next_game){
						$output .= "<tr><td><a href=\"".JRoute::_( 'index.php?option=com_minigame&controller=minigame&task=play_game&id='. $game->id_mini_game )."\">".$game->name."</a></td><td>0</td><td><div style=\"width: 0%; overflow-x: hidden; height: 30px;\"><img class=\"star1\" src=\"".$rootpath . 'images/stories/' . $media->folder_root . $media->file_name."\" /></div></td></tr>";
						$play_next_game = false;
					}else{
						$output .= "<tr><td>".$game->name."</td><td>0</td><td><div style=\"width: 0%; overflow-x: hidden; height: 30px;\"><img class=\"star1\" src=\"".$rootpath . 'images/stories/' . $media->folder_root . $media->file_name."\" /></div></td></tr>";
					}
				}
			}
		}
		$output .="</table></div></div>";
		$this->assignRef('games', $output);
	}
	
	// Method to set variables to play game. the output will be generated on playgame.php
	function playgame()
	{
		//variables
		$this->assignRef('id_mini_game', JRequest::getVar( 'id_mini_game'));
		$path = JPATH_COMPONENT.DS.'codigo'.DS;
		$this->assignRef('path', $path);
		$this->assignRef('player_id', JFactory::getUser()->id);
		$this->assignRef('player_name', JFactory::getUser()->username);
		
		//get minigame
		$db =& JFactory::getDBO();
		$sql = 'SELECT * FROM #__minigame WHERE active = 1 AND id_mini_game = ' . $this->id_mini_game;
      	$db->setQuery($sql);
		$result_game = $db->loadObject();
		$this->assignRef('mini_game', $result_game);
		
		//get payoff table
		$sql = 'SELECT * FROM #__payofftable WHERE id_payoff_table = ' . $this->mini_game->id_payoff_table;
      	$db->setQuery($sql);
		$result_payofftable = $db->loadObject();
		$this->assignRef('payofftable', $result_payofftable);
		
		//get opponent
		$sql = 'SELECT * FROM #__opponent WHERE id_opponent = ' . $this->mini_game->id_opponent;
      	$db->setQuery($sql);
		$result_opponent = $db->loadObject();
		$this->assignRef('opponent', $result_opponent);
		
		//get opponent strategy
		$sql = 'SELECT * FROM #__strategy WHERE id_strategy = ' . $this->mini_game->id_strategy;
      	$db->setQuery($sql);
		$result_strategy = $db->loadObject();
		$this->assignRef('strategy', $result_strategy);
		
		//get minigame bg_image
		$sql = 'SELECT * FROM #__minigamemedia WHERE id_mini_game = ' . $this->id_mini_game .' AND goal = "bg_image"';
      	$db->setQuery($sql);
		$media_image = $db->loadObject();
		$this->assignRef('media_image', $media_image);
		
		//get minigame stars
		$sql = 'SELECT * FROM #__minigamemedia WHERE id_mini_game = ' . $this->id_mini_game .' AND goal = "stars"';
      	$db->setQuery($sql);
		$stars = $db->loadObject();
		$this->assignRef('stars', $stars);
		
		//$sql = 'SELECT * FROM #__minigamemedia WHERE id_mini_game = ' . $this->id_mini_game .' AND goal = "bg_sound"';
      	//$db->setQuery($sql);
		//$media_image = $db->loadObject();
		//$this->assignRef('media_sound', $media_sound);
		
		//$sql = 'SELECT * FROM #__minigamemedia WHERE id_mini_game = ' . $this->id_mini_game .' AND goal = "video"';
      	//$db->setQuery($sql);
		//$media_image = $db->loadObject();
		//$this->assignRef('media_video', $media_video);
	}
	
	// Method to show game-theme intro text
	function showgameintro()
	{
		//variables
		$this->assignRef('id_mini_game', JRequest::getVar( 'id_mini_game'));
		$rootpath = JURI::root();
		
		//get intro text from theme of the game
		$db =& JFactory::getDBO();
		$sql = 'SELECT * FROM #__minigame, #__theme WHERE #__minigame.id_theme = #__theme.id_theme AND id_mini_game = ' . $this->id_mini_game;
      	$db->setQuery($sql);
		$info = $db->loadObject();
		
		//get bg_image of the game
		$sql = 'SELECT * FROM #__minigamemedia WHERE goal = "bg_image" AND id_mini_game = ' . $this->id_mini_game;
      	$db->setQuery($sql);
		$media = $db->loadObject();
		
		$output = '<div id="div_game_intro" style="background-image:url(' . $rootpath . 'images/stories/' . $media->folder_root . $media->file_name . ')"><p id="intro_txt_area" class="game_txt">' . $info->intro_txt . '</p></div>';
		
		$this->assignRef('output', $output);
	}
	
	// Method to show the payoff table
	function showpayofftable()
	{
		//variables
		$this->assignRef('id_mini_game', JRequest::getVar( 'id_mini_game'));
		$rootpath = JURI::root();
		
		//get payoff table
		$db =& JFactory::getDBO();
		$sql = 'SELECT * FROM #__payofftable WHERE id_payoff_table = ( SELECT id_payoff_table FROM #__minigame WHERE show_payoff_table = 1 AND id_mini_game = ' . $this->id_mini_game.')';
      	$db->setQuery($sql);
		$info = $db->loadObject();
		
		//get opponent to retrieve the name
		$db =& JFactory::getDBO();
		$sql = 'SELECT * FROM #__opponent WHERE id_opponent = ( SELECT id_opponent FROM #__minigame WHERE id_mini_game = ' . $this->id_mini_game.')';
      	$db->setQuery($sql);
		$opponent = $db->loadObject();
		
		//get bg_image of the game
		$sql = 'SELECT * FROM #__minigamemedia WHERE goal = "bg_image" AND id_mini_game = ' . $this->id_mini_game;
      	$db->setQuery($sql);
		$media = $db->loadObject();
		
		$output='<div id="payoff_table" style="background-image:url(' . $rootpath . 'images/stories/' . $media->folder_root . $media->file_name . ')">';
		$output.='<div id="payoff_table_top">';
		$output.='<div id="payoff_table_opponent">'.$opponent->name.'</div>';
		$output.='<div id="payoff_table_opponent_coop">'.$info->coop_txt.'</div>';
		$output.='<div id="payoff_table_opponent_defe">'.$info->defe_txt.'</div>';
		$output.='</div>';
		$output.='<div id="payoff_table_left">';
		$output.='<div id="payoff_table_player">'.JFactory::getUser()->username.'</div>';
		$output.='<div id="payoff_table_player_coop">'.$info->coop_txt.'</div>';
		$output.='<div id="payoff_table_player_defe">'.$info->defe_txt.'</div>';
		$output.='</div>';
		$output.='<div id="payoff_table_center">';
		$output.='<div id="payoff_1"><div id="opponent_1" class="opponent_payoff">'.$info->opponent_1.'</div><div id="player_1" class="player_payoff">'.$info->player_1.'</div></div>';
		$output.='<div id="payoff_2"><div id="opponent_2" class="opponent_payoff">'.$info->opponent_2.'</div><div id="player_2" class="player_payoff">'.$info->player_2.'</div></div>';
		$output.='<div id="payoff_3"><div id="opponent_3" class="opponent_payoff">'.$info->opponent_3.'</div><div id="player_3" class="player_payoff">'.$info->player_3.'</div></div>';
		$output.='<div id="payoff_4"><div id="opponent_4" class="opponent_payoff">'.$info->opponent_4.'</div><div id="player_4" class="player_payoff">'.$info->player_4.'</div></div>';
		$output.='</div>';
		$output.='</div>';
		
		$this->assignRef('output', $output);
	}
	
	// Method to show opponent extra info
	function showopponent()
	{
		//variables
		$this->assignRef('id_mini_game', JRequest::getVar( 'id_mini_game'));
		$rootpath = JURI::root();
		
		//get opponent
		$db =& JFactory::getDBO();
		$sql = 'SELECT * FROM #__opponent WHERE id_opponent = ( SELECT id_opponent FROM #__minigame WHERE id_mini_game = ' . $this->id_mini_game.')';
      	$db->setQuery($sql);
		$opponent = $db->loadObject();
		
		//get bg_image of the game
		$sql = 'SELECT * FROM #__minigamemedia WHERE id_mini_game = ' . $this->id_mini_game .' AND goal = "bg_image"';
      	$db->setQuery($sql);
		$media = $db->loadObject();
		
		$output='<div id="div_opponent" style="background-image:url(' . $rootpath . 'images/stories/' . $media->folder_root . $media->file_name . ')">';
		$output.='<div id="opponent_image_txt">';
		$output.='<img id="opponent_image2" src="' . $rootpath . 'images/stories/' . $opponent->folder_root . $opponent->file_name .'" width="260px" height="260px">';
		$output.='<p class="game_txt2">'.$opponent->name.'</p>';
		$output.='<p class="game_txt3"><b>Informação: </b>'.$opponent->description.'</p>';
		$output.='</div>';
		$output.='</div>';
		
		$this->assignRef('output', $output);
	}
	
	// Method to show game top10 players
	function showtop10()
	{
		$this->assignRef('id_mini_game', JRequest::getVar( 'id_mini_game'));
		$rootpath = JURI::root();
		$output = "";
		
		//get points top 10 
		$db =& JFactory::getDBO();
		$sql = 'SELECT * FROM (SELECT id_mini_game, id_user, date, time_length, sum(player_payoff) as points FROM #__move WHERE id_mini_game = ' . $this->id_mini_game.' GROUP BY id_mini_game, id_user, date, time_length ORDER BY sum(player_payoff) DESC, time_length ASC, date ASC  LIMIT 10) AUX LEFT JOIN (SELECT id, name  FROM #__users) AUX2 ON AUX.id_user = AUX2.id';
      	$db->setQuery($sql);
		$rows = $db->loadObjectList();
		
		//get stars image
		$sql = 'SELECT * FROM #__minigamemedia WHERE id_mini_game = ' . $this->id_mini_game .' AND goal = "stars"';
      	$db->setQuery($sql);
		$media = $db->loadObject();
		
		//get max points and percentage
		$sql = 'SELECT * FROM #__minigame, #__payofftable WHERE #__minigame.id_payoff_table = #__payofftable.id_payoff_table and id_mini_game = ' . $this->id_mini_game;
      	$db->setQuery($sql);
		$top = $db->loadObject();
		
		//build the list
		$output .="<table id=\"points_table\"><tr><th>".JText::_(' Posição ')."</th><th>".JText::_(' Nome ')."</th><th>".JText::_(' Dia ')."</th><th>".JText::_(' Duração ')."</th><th>".JText::_(' Pontos ')."</th><th> </th></tr>";
		$i = 1;
		foreach($rows as $row){
			if($row->points <= 0){
				$percentagem = 0;
			}else{
				$percentagem = ($row->points)/($top->player_3 * $top->n_rounds);
			}
			
			$output .= "<tr><td>".$i."</td><td>".$row->name."</td><td>".$row->date."</td><td>".$row->time_length."</td><td>".$row->points."</td><td><div style=\"width: ".($percentagem * 100)."%; overflow-x: hidden; height: 30px;\"><img class=\"star1\" src=\"".$rootpath . 'images/stories/' . $media->folder_root . $media->file_name."\" /></div></td></tr>";
			$i++;
		}
		$output .="</table>";
		
		$this->assignRef('output', $output);
	}
}	