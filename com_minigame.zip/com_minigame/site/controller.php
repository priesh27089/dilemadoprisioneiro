<?

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.controller');

class MinigameController extends JController
{
	/**
	 * Method to display the view
	 */
	function display()
	{	
		parent::display();
	}
	// Method to view game lists of a theme 
	function list_minigames()
	{
		JRequest::setVar( 'view', 'minigame' );
		JRequest::setVar( 'layout', 'games_list' );
		JRequest::setVar( 'id_theme', JRequest::getVar( 'id' ));
		parent::display();
	}
	// Method to view theme list
	function list_themes()
	{
		JRequest::setVar( 'view', 'minigame' );
		JRequest::setVar( 'layout', 'default' );
		parent::display();
	}
	// Method to play a selected game
	function play_game()
	{
		JRequest::setVar( 'view', 'minigame' );
		JRequest::setVar( 'layout', 'playgame' );
		JRequest::setVar( 'id_mini_game', JRequest::getVar( 'id' ));
		parent::display();
	}
	// Method to view theme intro text
	function showgameintro()
	{
		JRequest::setVar( 'view', 'minigame' );
		JRequest::setVar( 'layout', 'info' );
		JRequest::setVar( 'id_mini_game', JRequest::getVar( 'id' ));
		JRequest::setVar( 'info', 'showgameintro');
		parent::display();
	}
	// Method to view payoff table
	function showpayofftable()
	{
		JRequest::setVar( 'view', 'minigame' );
		JRequest::setVar( 'layout', 'info' );
		JRequest::setVar( 'id_mini_game', JRequest::getVar( 'id' ));
		JRequest::setVar( 'info', 'showpayofftable');
		parent::display();
	}
	// Method to view opponent
	function showopponent()
	{
		JRequest::setVar( 'view', 'minigame' );
		JRequest::setVar( 'layout', 'info' );
		JRequest::setVar( 'id_mini_game', JRequest::getVar( 'id' ));
		JRequest::setVar( 'info', 'showopponent');
		parent::display();
	}
	// Method to view game top 10 players
	function showtop10()
	{
		JRequest::setVar( 'view', 'minigame' );
		JRequest::setVar( 'layout', 'info' );
		JRequest::setVar( 'id_mini_game', JRequest::getVar( 'id' ));
		JRequest::setVar( 'info', 'showtop10');
		parent::display();
	}
}
?>