<? 
$action = $_POST["action"];
$list = "";

if($action == "save_game"){
	include('../../../configuration.php');
	$jc = new JConfig();

	$status = "0";
	$id_game = $_POST['game_id'];
	$id_theme = $_POST['theme_id'];
	$id_user = $_POST['player_id'];
	$id_opp = $_POST['opp_id'];
	$round_n = $_POST['round_n'];
	$time_length = $_POST['time'];
	$now = date("Y/m/d h:i:s");
	$link = mysql_connect($jc->host, $jc->user, $jc->password);
	$db = mysql_select_db($jc->db, $link);
	
	for($i = 0; $i < $round_n; $i++){
		$player_move = utf8_decode($_POST['player_move'.$i]);
		$opp_move = utf8_decode($_POST['opp_move'.$i]);
		$player_payoff = $_POST['player_payoff'.$i];
		$opp_payoff = $_POST['opp_payoff'.$i];
		
		$query = "INSERT INTO `".$jc->dbprefix."move` (id_theme, id_mini_game, id_user, date, step, player_answer, opponent_answer, player_payoff, opponent_payoff, time_length) VALUES ('".$id_theme."', '".$id_game."', '".$id_user."', STR_TO_DATE('".$now."','%Y/%m/%d %H:%i:%s') , '".$i."', '".$player_move."', '".$opp_move."', '".$player_payoff."', '".$opp_payoff."', TIME('00:".$time_length."'))";
		
		If(!mysql_query($query, $link)){
			$status = "-1";
		}
	}
	echo $status;
}
?>