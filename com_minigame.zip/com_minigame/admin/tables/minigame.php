<?php
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Minigame Table class
 */
class TableMinigame extends JTable
{
	var $id_mini_game = null;
	var $name = null;
	var $position = null;
	var $question = null;
	var $show_payoff_table = null;
	var $message_moves = null;
	var $n_rounds = null;
  	var $target_points_perc = null;
  	var $message_win = null;
  	var $message_lose = null;
	var $active = null;
	var $id_theme = null;
	var $id_opponent = null;
	var $id_payoff_table = null;
	var $id_strategy = null;
	var $theme_name = null;
	var $opponent_name = null;
	var $strategy_name = null;
	var $payofftable_name = null;
	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function TableMinigame(& $db) {
		parent::__construct('#__minigame', 'id_mini_game', $db);
	}
}