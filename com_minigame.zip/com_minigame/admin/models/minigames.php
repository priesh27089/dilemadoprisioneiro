<?php
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.model' );

class MinigamesModelMinigames extends JModel
{
	/**
	 * Minigames data array
	 * @var array
	 */
	var $_data;
	
	/**
	 * Returns the query
	 * @return string The query to be used to retrieve the rows from the database
	 */
	function _buildQuery()
	{
		$query = ' SELECT #__minigame.id_mini_game, 
			#__minigame.name, 
			#__minigame.position,
			#__minigame.question,
			#__minigame.show_payoff_table,
			#__minigame.message_moves,
			#__minigame.n_rounds,
  			#__minigame.target_points_perc,
  			#__minigame.message_win,
  			#__minigame.message_lose,
			#__minigame.active,
			#__minigame.id_theme,
			#__minigame.id_opponent,
			#__minigame.id_payoff_table,
			#__minigame.id_strategy,
			#__theme.name as theme_name,
			#__opponent.name as opponent_name,
			#__strategy.name as strategy_name,
			#__payofftable.name as payofftable_name '.
			'
			FROM #__minigame, #__theme, #__opponent, #__strategy, #__payofftable 
			WHERE #__minigame.id_theme = #__theme.id_theme 
			and #__minigame.id_opponent = #__opponent.id_opponent
			and #__minigame.id_strategy = #__strategy.id_strategy
			and #__minigame.id_payoff_table = #__payofftable.id_payoff_table 
			ORDER BY #__minigame.id_theme, #__minigame.position ASC';
		return $query;
	}

	/**
	 * Retrieves the Minigame data
	 * @return array Array of objects containing the data from the database
	 */
	function getData()
	{
		// Lets load the data if it doesn't already exist
		if (empty( $this->_data ))
		{
			$query = $this->_buildQuery();
			$this->_data = $this->_getList( $query );
		}
		return $this->_data;
	}
}