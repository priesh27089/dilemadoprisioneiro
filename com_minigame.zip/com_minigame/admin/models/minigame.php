<?php
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.application.component.model');

class MinigamesModelMinigame extends JModel
{
	/**
	 * Constructor that retrieves the ID from the request
	 * @access	public
	 * @return	void
	 */
	function __construct()
	{
		parent::__construct();
		$array = JRequest::getVar('cid',  0, '', 'array');
		$this->setId((int)$array[0]);
	}

	/**
	 * Method to set the Minigame identifier
	 * @access	public
	 * @param	int Minigame identifier
	 * @return	void
	 */
	function setId($id)
	{
		// Set id and wipe data
		$this->_id		= $id;
		$this->_data	= null;
	}

	/**
	 * Method to get a minigame
	 * @return object with data
	 */
	function &getData()
	{
		// Load the data
		if (empty( $this->_data )) {
			$query = ' SELECT #__minigame.id_mini_game, 
			#__minigame.name, 
			#__minigame.position,
			#__minigame.question,
			#__minigame.show_payoff_table,
			#__minigame.message_moves,
			#__minigame.n_rounds,
  			#__minigame.target_points_perc,
  			#__minigame.message_win,
  			#__minigame.message_lose,
			#__minigame.active,
			#__minigame.id_theme,
			#__minigame.id_opponent,
			#__minigame.id_payoff_table,
			#__minigame.id_strategy,
			#__theme.name as theme_name,
			#__opponent.name as opponent_name,
			#__strategy.name as strategy_name,
			#__payofftable.name as payofftable_name
			FROM #__minigame, #__theme, #__opponent, #__strategy, #__payofftable '.
			'  WHERE #__minigame.id_theme = #__theme.id_theme 
			and #__minigame.id_opponent = #__opponent.id_opponent
			and #__minigame.id_strategy = #__strategy.id_strategy
			and #__minigame.id_payoff_table = #__payofftable.id_payoff_table 
			and #__minigame.id_mini_game = '.$this->_id;
			$this->_db->setQuery( $query );
			$this->_data = $this->_db->loadObject();
		}
		if (!$this->_data) {
			$this->_data = new stdClass();
			$this->_data->id_mini_game = 0;
			$this->_data->minigame_name = null;
			$this->_data->position = null;
			$this->_data->question = null;
			$this->_data->show_payofftable = null;
			$this->_data->message_moves = null;
			$this->_data->n_rounds = null;
  			$this->_data->target_points_perc = null;
  			$this->_data->message_win = null;
  			$this->_data->message_lose = null;
			$this->_data->active = null;
			$this->_data->id_theme = null;
			$this->_data->id_opponent = null;
			$this->_data->id_payoff_table = null;
			$this->_data->id_strategy = null;
			$this->_data->theme_name = null;
			$this->_data->opponent_name = null;
			$this->_data->strategy_name = null;
			$this->_data->payofftable_name = null;
		}
		return $this->_data;
	}

	/**
	 * Method to store a record
	 * @access	public
	 * @return	boolean	True on success
	 */
	function store()
	{	
		$row =& $this->getTable();
		$data = JRequest::get( 'post' );

		// Bind the form fields to the minigame table
		if (!$row->bind($data)) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		// Make sure the minigame record is valid
		if (!$row->check()) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		// Store the web link table to the database
		if (!$row->store()) {
			$this->setError( $row->getErrorMsg() );
			return false;
		}
		return true;
	}

	/**
	 * Method to delete record(s)
	 * @access	public
	 * @return	boolean	True on success
	 */
	function delete()
	{
		$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
		$row =& $this->getTable();

		if (count( $cids )) {
			foreach($cids as $cid) {
				if (!$row->delete( $cid )) {
					$this->setError( $row->getErrorMsg() );
					return false;
				}
			}
		}
		return true;
	}

}