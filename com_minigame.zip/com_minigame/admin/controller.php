<?php
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.application.component.controller');

class MinigamesController extends JController
{
	/**
	 * Method to display the view
	 */
	function display()
	{
		parent::display();
	}
}