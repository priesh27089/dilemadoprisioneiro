<?php
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

class MinigamesViewMinigame extends JView
{
	/**
	 * display method of Minigame view
	 * @return void
	 **/
	function display($tpl = null)
	{
		//get themes
		$db =& JFactory::getDBO();
		$sql = 'SELECT id_theme, name' . ' FROM #__theme';
      	$db->setQuery($sql);
      	$themelist[] = JHTML::_('select.option', '1', '- Selecione um Tema -', 'id_theme', 'name' );
    	$themelist = array_merge( $themelist, $db->loadObjectList() );
		
		//get opponents
		$db =& JFactory::getDBO();
		$sql = 'SELECT id_opponent, name' . ' FROM #__opponent';
      	$db->setQuery($sql);
      	$opponentlist[] = JHTML::_('select.option', '1', '- Selecione um Adversário -', 'id_opponent', 'name' );
    	$opponentlist = array_merge( $opponentlist, $db->loadObjectList() );
		
		//get strategy
		$db =& JFactory::getDBO();
		$sql = 'SELECT id_strategy, name' . ' FROM #__strategy';
      	$db->setQuery($sql);
      	$strategylist[] = JHTML::_('select.option', '1', '- Selecione uma Estratégia -', 'id_strategy', 'name' );
    	$strategylist = array_merge( $strategylist, $db->loadObjectList() );
		
		//get payofftable
		$db =& JFactory::getDBO();
		$sql = 'SELECT id_payoff_table, name' . ' FROM #__payofftable';
      	$db->setQuery($sql);
      	$payofftablelist[] = JHTML::_('select.option', '1', '- Selecione uma Tabela de Ganhos -', 'id_payoff_table', 'name' );
    	$payofftablelist = array_merge( $payofftablelist, $db->loadObjectList() );
		
		//get the minigame
		$minigame =& $this->get('Data');
		$isNew = ($minigame->id_mini_game < 1);

		$text = $isNew ? JText::_( 'New' ) : JText::_( 'Edit' );
		JToolBarHelper::title(   JText::_( 'Mini Game (Jogo)' ).': <small><small>[ ' . $text.' ]</small></small>' , 'generic.png');
		JToolBarHelper::save();
		if ($isNew)  {
			JToolBarHelper::cancel();
		} else {
			// for existing items the button is renamed `close`
			JToolBarHelper::cancel( 'cancel', 'Close' );
		}

		$this->assignRef('minigame', $minigame);
		$this->assignRef('themelist', $themelist);
		$this->assignRef('opponentlist', $opponentlist);
		$this->assignRef('strategylist', $strategylist);
		$this->assignRef('payofftablelist', $payofftablelist);

		parent::display($tpl);
	}
}