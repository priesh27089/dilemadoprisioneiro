<?php defined('_JEXEC') or die('Restricted access'); ?>

<form action="index.php" method="post" name="adminForm" id="adminForm">
<div class="col150px">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'Detalhes' ); ?></legend>

		<table class="admintable">
		<tr>
			<td width="150px" align="right" class="key">
				<label for="name">
					<?php echo JText::_( 'Tema' ); ?>:
				</label>
			</td>
			<td>
            	<? 
				$themes = JHTML::_('select.genericlist', $this->themelist, 'id_theme', null,'id_theme', 'name', $this->minigame->id_theme );
				echo $themes;
				?>
			</td>
		</tr>
        <tr>
			<td width="150px" align="right" class="key">
				<label for="folder_root">
					<?php echo JText::_( 'Nome' ); ?>:
				</label>
			</td>
			<td>
				<input class="text_area" type="text" name="name" id="name" size="45" maxlength="45" value="<?php echo $this->minigame->name;?>" />
			</td>
		</tr>
        <tr>
			<td width="150px" align="right" class="key">
				<label for="folder_root">
					<?php echo JText::_( 'Posição '); ?><br /> <?php echo JText::_( ' ex: 1, 2, 3,...'); ?>
				</label>
			</td>
			<td>
				<input class="text_area" type="text" name="position" id="position" size="50" maxlength="250" value="<?php echo $this->minigame->position;?>" />
			</td>
		</tr>
        <tr>
			<td width="150px" align="right" class="key">
				<label for="folder_root">
					<?php echo JText::_( 'Pergunta do Jogo' ); ?>:
				</label>
			</td>
			<td>
				<input class="text_area" type="text" name="question" id="question" size="50" maxlength="250" value="<?php echo $this->minigame->question;?>" />
			</td>
		</tr>
        <tr>
			<td width="150px" align="right" class="key">
				<label for="folder_root">
					<?php echo JText::_( 'Mensagem PopUp no final de cada Iteração' ); ?>:
				</label>
			</td>
			<td>
				<input class="text_area" type="text" name="message_moves" id="message_moves" size="50" maxlength="250" value="<?php echo $this->minigame->message_moves;?>" />
			</td>
		</tr>
        <tr>
			<td width="150px" align="right" class="key">
				<label for="folder_root">
					<?php echo JText::_( 'Número de Iterações' ); ?>:
				</label>
			</td>
			<td>
				<input class="text_area" type="text" name="n_rounds" id="n_rounds" size="50" maxlength="250" value="<?php echo $this->minigame->n_rounds;?>" />
			</td>
		</tr><tr>
			<td width="150px" align="right" class="key">
				<label for="folder_root">
					<?php echo JText::_( 'Percentagem de Pontos para vencer o Adversário e Jogar o Proximo Jogo (ex: 0.5)' ); ?>:
				</label>
			</td>
			<td>
				<input class="text_area" type="text" name="target_points_perc" id="target_points_perc" size="50" maxlength="250" value="<?php echo $this->minigame->target_points_perc;?>" />
			</td>
		</tr><tr>
			<td width="150px" align="right" class="key">
				<label for="folder_root">
					<?php echo JText::_( 'Mensagem quando Jogador vence o Jogo' ); ?>:
				</label>
			</td>
			<td>
				<input class="text_area" type="text" name="message_win" id="message_win" size="50" maxlength="250" value="<?php echo $this->minigame->message_win;?>" />
			</td>
		</tr><tr>
			<td width="150px" align="right" class="key">
				<label for="folder_root">
					<?php echo JText::_( 'Mensagem quando Jogador perde o Jogo' ); ?>:
				</label>
			</td>
			<td>
				<input class="text_area" type="text" name="message_lose" id="message_lose" size="50" maxlength="250" value="<?php echo $this->minigame->message_lose;?>" />
			</td>
		</tr>
        <tr>
			<td width="150px" align="right" class="key">
				<label for="description">
                	<?php echo JText::_( 'Estado' ); ?>:
				</label>
			</td>
			<td>
            	<input id="active" name="active" type="radio" value="1" <? if($this->minigame->active == "1") { echo "checked"; } ?>/> <? echo JText::_( "Activo") ?> <br />
            	<input id="active" name="active" type="radio" value="0" <? if($this->minigame->active == "0") { echo "checked"; } ?>/> <? echo JText::_( "Inactivo") ?> <br />
			</td>
		</tr>
        <tr>
			<td width="150px" align="right" class="key">
				<label for="description">
                	<?php echo JText::_( 'Mostrar Tabela de Ganhos' ); ?>:
				</label>
			</td>
			<td>
            	<input id="show_payoff_table" name="show_payoff_table" type="radio" value="0" <? if($this->minigame->show_payoff_table == "0") { echo "checked"; } ?>/> <? echo JText::_( "Não") ?> <br />
            	<input id="show_payoff_table" name="show_payoff_table" type="radio" value="1" <? if($this->minigame->show_payoff_table != "0") { echo "checked"; } ?>/> <? echo JText::_( "Sim") ?> <br />
			</td>
		</tr>
        <tr>
			<td width="150px" align="right" class="key">
				<label for="name">
					<?php echo JText::_( 'Tabela de Ganhos' ); ?>:
				</label>
			</td>
			<td>
            	<? 
				$payofftables = JHTML::_('select.genericlist', $this->payofftablelist, 'id_payoff_table', null,'id_payoff_table', 'name', $this->minigame->id_payoff_table );
				echo $payofftables;
				?>
			</td>
		</tr>
        <tr>
			<td width="150px" align="right" class="key">
				<label for="name">
					<?php echo JText::_( 'Adversário' ); ?>:
				</label>
			</td>
			<td>
            	<? 
				$opponents = JHTML::_('select.genericlist', $this->opponentlist, 'id_opponent', null,'id_opponent', 'name', $this->minigame->id_opponent );
				echo $opponents;
				?>
			</td>
		</tr>
        <tr>
			<td width="150px" align="right" class="key">
				<label for="name">
					<?php echo JText::_( 'Estratégia do Adversário' ); ?>:
				</label>
			</td>
			<td>
            	<? 
				$strategies = JHTML::_('select.genericlist', $this->strategylist, 'id_strategy', null,'id_strategy', 'name', $this->minigame->id_strategy );
				echo $strategies;
				?>
			</td>
		</tr>
	</table>
	</fieldset>
</div>
<div class="clr"></div>

<input type="hidden" name="option" value="com_minigame" />
<input type="hidden" name="controller" value="minigame" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="id_mini_game" value="<?php echo $this->minigame->id_mini_game; ?>" />
</form>
