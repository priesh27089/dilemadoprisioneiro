<?php defined('_JEXEC') or die('Restricted access'); ?>
<form action="index.php" method="post" name="adminForm">
<div id="editcell">
	<table class="adminlist">
	<thead>
		<tr>
			<th width="5">
				<?php echo JText::_( 'ID' ); ?>
			</th>
			<th width="20">
				<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $this->items ); ?>);" />
			</th>			
			<th>
				<?php echo JText::_( 'Tema' ); ?>
			</th>
            <th>
				<?php echo JText::_( 'Jogo' ); ?>
			</th>
            <th>
				<?php echo JText::_( 'Ordem' ); ?>
			</th>
            <th>
				<?php echo JText::_( 'Estado' ); ?>
			</th>
		</tr>
	</thead>
	<?php
	$k = 0;
	for ($i=0, $n=count( $this->items ); $i < $n; $i++)	{
		$row = &$this->items[$i];
		$checked 	= JHTML::_('grid.id',   $i, $row->id_mini_game );
		$link 		= JRoute::_( 'index.php?option=com_minigame&controller=minigame&task=edit&cid[]='. $row->id_mini_game );
		?>
		<tr class="<?php echo "row" . $k; ?>">
			<td>
				<?php echo $row->id_mini_game; ?>
			</td>
			<td>
				<?php echo $checked; ?>
			</td>
			<td>
				<a href="<?php echo $link; ?>"><?php echo $row->theme_name; ?></a>
			</td>
            <td>
				<a href="<?php echo $link; ?>"><?php echo $row->name; ?></a>
			</td>
            <td>
				<a href="<?php echo $link; ?>"><?php echo $row->position; ?></a>
			</td>
            <td>
				<? 
                if($row->active == 1){
                    echo '<a href='. $link .'> Activo </a>';
                }else{
                    echo '<a href='. $link .'> Inactivo </a>';
                    }
                ?>
			</td>
        </tr>
		<?php
		$k = 1 - $k;
	}
	?>
	</table>
</div>

<input type="hidden" name="option" value="com_minigame" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="minigame" />
</form>
