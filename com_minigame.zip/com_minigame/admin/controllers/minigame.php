<?php
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class minigamesControllerminigame extends minigamesController
{
	/**
	 * constructor (registers additional tasks to methods)
	 * @return void
	 */
	function __construct()
	{
		parent::__construct();
		// Register Extra tasks
		$this->registerTask( 'add'  , 	'edit' );
	}

	/**
	 * display the edit form
	 * @return void
	 */
	function edit()
	{
		JRequest::setVar( 'view', 'minigame' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar('hidemainmenu', 1);
		parent::display();
	}

	/**
	 * save a record (and redirect to main page)
	 * @return void
	 */
	function save()
	{
		$model = $this->getModel('minigame');
		
		//get data from request
		$post = JRequest::get('post');

		if ($model->store($post)) {
			$msg = JText::_( 'Alterações Gravadas!' );
		} else {
			$msg = JText::_( 'Erro ao gravar o as alterações' );
		}
		// Check the table in so it can be edited.... we are done with it anyway
		$link = 'index.php?option=com_minigame';
		$this->setRedirect($link, $msg);
	}

	/**
	 * remove record(s)
	 * @return void
	 */
	function remove()
	{
		$model = $this->getModel('minigame');
		if(!$model->delete()) {
			$msg = JText::_( 'Erro: Não foi possivel eliminar um ou mais elementos' );
		} else {
			$msg = JText::_( 'Elementos(s) Removido' );
		}

		$this->setRedirect( 'index.php?option=com_minigame', $msg );
	}

	/**
	 * cancel editing a record
	 * @return void
	 */
	function cancel()
	{
		$msg = JText::_( 'Operação Cancelada' );
		$this->setRedirect( 'index.php?option=com_minigame', $msg );
	}
}