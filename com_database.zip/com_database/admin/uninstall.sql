-- *** DROPS ***
DROP TABLE IF EXISTS `#__move`;
DROP TABLE IF EXISTS `#__minigamemedia`;
DROP TABLE IF EXISTS `#__thememedia`;
DROP TABLE IF EXISTS `#__minigame`;
DROP TABLE IF EXISTS `#__theme`;
DROP TABLE IF EXISTS `#__payofftable`;
DROP TABLE IF EXISTS `#__opponent`;
DROP TABLE IF EXISTS `#__strategy`;