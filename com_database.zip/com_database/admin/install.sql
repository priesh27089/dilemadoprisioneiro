-- *** DROPS ***
DROP TABLE IF EXISTS `#__move`;
DROP TABLE IF EXISTS `#__minigamemedia`;
DROP TABLE IF EXISTS `#__thememedia`;
DROP TABLE IF EXISTS `#__minigame`;
DROP TABLE IF EXISTS `#__theme`;
DROP TABLE IF EXISTS `#__payofftable`;
DROP TABLE IF EXISTS `#__opponent`;
DROP TABLE IF EXISTS `#__strategy`;


-- *** Theme ***
CREATE TABLE `#__theme` (
  `id_theme` int(11) NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `intro_txt` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY  (`id_theme`)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;
INSERT INTO `#__theme` (`name`, `intro_txt`, `active`) VALUES ('War and Peace', 'Estás no centro de uma batalha no Afeganistão! <br />O teu Objectivo é trazer a Paz ao seu povo. <br />Para acabar com a guerra, tens de derrotar o Líder, mas para isso terás de vencer primeiro os seus aliados.', 1);


-- *** Theme Media ***
CREATE TABLE `#__thememedia` (
  `id_media` int(11) NOT NULL auto_increment,
  `id_theme` int NOT NULL,
  `goal` varchar(45) NOT NULL,
  `file_name` varchar(45) NOT NULL,
  `folder_root` varchar(255) NULL,
  PRIMARY KEY (`id_media`),
  CONSTRAINT `FK_THEMEMEDIA`
   FOREIGN KEY (`id_theme`)
   REFERENCES `dilemma`.`#__theme` (`id_theme`)
   ON DELETE RESTRICT
   ON UPDATE CASCADE
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;
INSERT INTO `#__thememedia` (`id_theme`, `goal`, `file_name`, `folder_root`) VALUES (1, 'bg_image', 'warpeace.jpg', '');


-- *** Payoff Table ***
CREATE TABLE `#__payofftable` (
  `id_payoff_table` int(11) NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `coop_txt` varchar(255) NOT NULL,
  `defe_txt` varchar(255) NOT NULL,
  `player_1` INT DEFAULT 0,
  `player_2` INT DEFAULT 0,
  `player_3` INT DEFAULT 0,
  `player_4` INT DEFAULT 0,
  `opponent_1` INT DEFAULT 0,
  `opponent_2` INT DEFAULT 0,
  `opponent_3` INT DEFAULT 0,
  `opponent_4` INT DEFAULT 0,
  PRIMARY KEY  (`id_payoff_table`)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;
INSERT INTO `#__payofftable` (`name`, `description`, `coop_txt`, `defe_txt`, `player_1`, `player_2`, `player_3`, `player_4`, `opponent_1`, `opponent_2`, `opponent_3`, `opponent_4`) VALUES ('Tabela de Ganhos Genérica', 'Tabela de Ganhos Genérica', 'Não Atacar', 'Atacar', 50, -50, 100, -20, 50, 100, -50, -20);


-- *** Opponent ***
CREATE TABLE `#__opponent` (
  `id_opponent` int(11) NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `description` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `folder_root` varchar(255) NULL,
  `goal` varchar(45) NOT NULL,
  PRIMARY KEY  (`id_opponent`)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;
INSERT INTO `#__opponent` (`name`, `description`, `file_name`, `folder_root`, `goal`) VALUES ('Talibã 1', 'Talibã sem arma', 'opponent_war_1.jpg', '', 'bg_image');
INSERT INTO `#__opponent` (`name`, `description`, `file_name`, `folder_root`, `goal`) VALUES ('Talibã 2', 'Protestantes Talibã', 'opponent_war_2.jpg', '', 'bg_image');
INSERT INTO `#__opponent` (`name`, `description`, `file_name`, `folder_root`, `goal`) VALUES ('Talibã Líder', 'Líder dos Talibã', 'opponent_war_3.jpg', '', 'bg_image');


-- *** Strategy ***
CREATE TABLE `#__strategy` (
  `id_strategy` int(11) NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `description` varchar(255) NOT NULL,
  `code` varchar(45) NOT NULL,
  `variable` varchar(255) DEFAULT NULL,
  PRIMARY KEY  (`id_strategy`)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;
INSERT INTO `#__strategy` (`name`, `description`, `code`) VALUES ('Cooperar', 'Cooperar sempre', 'cooperate');
INSERT INTO `#__strategy` (`name`, `description`, `code`, `variable`) VALUES ('Cooperar 0.7', 'Cooperar com percentagem de 0.7', 'random', '0.7');
INSERT INTO `#__strategy` (`name`, `description`, `code`) VALUES ('Tit for Tat', 'Tit for Tat', 'titfortat');


-- *** Mini Game ***
CREATE TABLE `#__minigame` (
  `id_mini_game` int(11) NOT NULL auto_increment,
  `id_theme` int NOT NULL,
  `name` varchar(45) NOT NULL,
  `position` INT NOT NULL,
  `question` varchar(255) NOT NULL,
  `show_payoff_table` TINYINT(1) NOT NULL DEFAULT '1',
  `message_moves` varchar(255) NOT NULL,
  `n_rounds` INT NOT NULL,
  `target_points_perc` FLOAT NOT NULL,
  `message_win` varchar(255) NOT NULL,
  `message_lose` varchar(255) NOT NULL,
  `active` TINYINT(1) NOT NULL DEFAULT '1',
  `id_payoff_table` INT NOT NULL,
  `id_strategy` INT NOT NULL,
  `id_opponent` INT NOT NULL,
  PRIMARY KEY  (`id_mini_game`,`id_theme`),
  CONSTRAINT `FK_THEME`
   FOREIGN KEY (`id_theme`)
   REFERENCES `dilemma`.`#__theme` (`id_theme`)
   ON DELETE RESTRICT
   ON UPDATE CASCADE,
CONSTRAINT `FK_PAYOFFTABLE`
   FOREIGN KEY (`id_payoff_table`)
   REFERENCES `dilemma`.`#__payofftable` (`id_payoff_table`)
   ON DELETE RESTRICT
   ON UPDATE CASCADE,
CONSTRAINT `FK_STRATEGY`
   FOREIGN KEY (`id_strategy`)
   REFERENCES `dilemma`.`#__strategy` (`id_strategy`)
   ON DELETE RESTRICT
   ON UPDATE CASCADE,
CONSTRAINT `FK_OPPONENT`
   FOREIGN KEY (`id_opponent`)
   REFERENCES `dilemma`.`#__opponent` (`id_opponent`)
   ON DELETE RESTRICT
   ON UPDATE CASCADE
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;
INSERT INTO `#__minigame` (`id_theme`, `name`, `position`, `question`, `show_payoff_table`, `message_moves`, `n_rounds`, `target_points_perc`, `message_win`, `message_lose`,`active`, `id_payoff_table`, `id_strategy`, `id_opponent`) VALUES (1, 'Primeiro Desafio', 1,'Não ataques os inocentes! Vence os que realmente estão a criar a Guerra!', 1, 'É o resultado que esperavas?! Se não, tenta melhor na próxima jogada!', 10, 0.5, 'Venceste o Adversário! Continua a tua luta pela Paz!','Não conseguiste vencer o Adversário. Tenta de novo e muda a tua estratégia!', 1, 1, 1, 1);
INSERT INTO `#__minigame` (`id_theme`, `name`, `position`, `question`, `show_payoff_table`, `message_moves`, `n_rounds`, `target_points_perc`, `message_win`, `message_lose`,`active`, `id_payoff_table`, `id_strategy`, `id_opponent`) VALUES (1, 'Segundo Desafio', 2,'Não ataques os inocentes! Vence os que realmente estão a criar a Guerra!', 1, 'É o resultado que esperavas?! Se não, tenta melhor na próxima jogada!', 10, 0.4, 'Venceste o Adversário! Continua a tua luta pela Paz!','Não conseguiste vencer o Adversário. Tenta de novo e muda a tua estratégia!', 1, 1, 2, 2);
INSERT INTO `#__minigame` (`id_theme`, `name`, `position`, `question`, `show_payoff_table`, `message_moves`, `n_rounds`, `target_points_perc`, `message_win`, `message_lose`,`active`, `id_payoff_table`, `id_strategy`, `id_opponent`) VALUES (1, 'Desafio Final', 3,'Não ataques os inocentes! Vence os que realmente estão a criar a Guerra!', 1, 'É o resultado que esperavas?! Se não, tenta melhor na próxima jogada!', 10, 0.4, 'Venceste o Adversário! Continua a tua luta pela Paz!','Não conseguiste vencer o Adversário. Tenta de novo e muda a tua estratégia!', 1, 1, 3, 3);

-- *** Mini Game Media ***
CREATE TABLE `#__minigamemedia` (
  `id_media` int(11) NOT NULL auto_increment,
  `id_mini_game` int NOT NULL,
  `goal` varchar(45) NOT NULL,
  `file_name` varchar(45) NOT NULL,
  `folder_root` varchar(255) NULL,
  PRIMARY KEY (`id_media`),
  CONSTRAINT `FK_MINIGAMEMEDIA`
   FOREIGN KEY (`id_mini_game`)
   REFERENCES `dilemma`.`#__minigame` (`id_mini_game`)
   ON DELETE RESTRICT
   ON UPDATE CASCADE
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;
INSERT INTO `#__minigamemedia` (`id_mini_game`, `goal`, `file_name`, `folder_root`) VALUES (1, 'bg_image', 'warpeace.jpg', '');
INSERT INTO `#__minigamemedia` (`id_mini_game`, `goal`, `file_name`, `folder_root`) VALUES (1, 'stars', 'stars.png', '');
INSERT INTO `#__minigamemedia` (`id_mini_game`, `goal`, `file_name`, `folder_root`) VALUES (2, 'bg_image', 'warpeace.jpg', '');
INSERT INTO `#__minigamemedia` (`id_mini_game`, `goal`, `file_name`, `folder_root`) VALUES (2, 'stars', 'stars.png', '');
INSERT INTO `#__minigamemedia` (`id_mini_game`, `goal`, `file_name`, `folder_root`) VALUES (3, 'bg_image', 'warpeace.jpg', '');
INSERT INTO `#__minigamemedia` (`id_mini_game`, `goal`, `file_name`, `folder_root`) VALUES (3, 'stars', 'stars.png', '');


-- *** Move ***
CREATE TABLE `#__move` (
  `id_theme` int NOT NULL,
  `id_mini_game` int(11) NOT NULL,
  `id_user` int NOT NULL,
  `date` DATETIME NOT NULL,
  `step` varchar(45) NOT NULL,
  `player_answer` varchar(255) NOT NULL,
  `opponent_answer` varchar(255) NOT NULL,
  `player_payoff` varchar(255) NOT NULL,
  `opponent_payoff` varchar(255) NOT NULL,
  `time_length` TIME NOT NULL,
  PRIMARY KEY (`id_theme`,`id_mini_game`,`id_user`,`date`,`step`),
  CONSTRAINT `FK_MOVEMINIGAME`
   FOREIGN KEY (`id_theme`,`id_mini_game`)
   REFERENCES `dilemma`.`#__minigame` (`id_theme`,`id_mini_game`)
   ON DELETE RESTRICT
   ON UPDATE CASCADE,
  CONSTRAINT `FK_MOVEUSER`
   FOREIGN KEY (`id_user`)
   REFERENCES `dilemma`.`#__users` (`id`)
   ON DELETE RESTRICT
   ON UPDATE CASCADE
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;