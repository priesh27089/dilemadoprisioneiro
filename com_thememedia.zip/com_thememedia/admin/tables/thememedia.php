<?php

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Thememedia Table class
 *
 */
class TableThememedia extends JTable
{
	var $id_media = null;
	var $file_name = null;
	var $folder_root = null;
	var $goal = null;
	var $id_theme = null;

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function TableThememedia(& $db) {
		parent::__construct('#__thememedia', 'id_media', $db);
	}
}