<?php

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

class ThememediasViewThememedia extends JView
{
	/**
	 * display method of Thememedia view
	 * @return void
	 **/
	function display($tpl = null)
	{
		//get themes
		$db =& JFactory::getDBO();
		$sql = 'SELECT id_theme, name' . ' FROM #__theme';
      	$db->setQuery($sql);
      	$themelist[] = JHTML::_('select.option', '1', '- Selecione um Tema -', 'id_theme', 'name' );
    	$themelist = array_merge( $themelist, $db->loadObjectList() );
      	//$themes = JHTML::_('select.genericlist', $themelist, 'id_theme', null,'id_theme', 'name', 1 );
		
		//get the thememedia
		$thememedia		=& $this->get('Data');
		$isNew		= ($thememedia->id_media < 1);

		$text = $isNew ? JText::_( 'New' ) : JText::_( 'Edit' );
		JToolBarHelper::title(   JText::_( 'Elemento Multimédia de Tema' ).': <small><small>[ ' . $text.' ]</small></small>' , 'generic.png');
		JToolBarHelper::save();
		if ($isNew)  {
			JToolBarHelper::cancel();
		} else {
			// for existing items the button is renamed `close`
			JToolBarHelper::cancel( 'cancel', 'Close' );
		}

		$this->assignRef('thememedia', $thememedia);
		//$this->assignRef('themes', $themes);
		$this->assignRef('themelist', $themelist);

		parent::display($tpl);
	}
}