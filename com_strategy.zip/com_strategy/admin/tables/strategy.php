<?php

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Strategy Table class
 *
 */
class TableStrategy extends JTable
{
	/**
	 * Primary Key
	 * @var int
	 */
	var $id_strategy = null;
	var $name = null;
	var $description = null;
	var $code = null;
	var $variable = null;

	
	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function TableStrategy(& $db) {
		parent::__construct('#__strategy', 'id_strategy', $db);
	}
}