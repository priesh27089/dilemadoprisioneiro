<?php

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

class StrategiesViewStrategy extends JView
{
	/**
	 * display method of Strategy view
	 * @return void
	 **/
	function display($tpl = null)
	{
		//get the opponent
		$strategy		=& $this->get('Data');
		$isNew		= ($strategy->id_strategy < 1);

		$text = $isNew ? JText::_( 'New' ) : JText::_( 'Edit' );
		JToolBarHelper::title(   JText::_( 'Estratégia' ).': <small><small>[ ' . $text.' ]</small></small>' , 'generic.png');
		JToolBarHelper::save();
		if ($isNew)  {
			JToolBarHelper::cancel();
		} else {
			// for existing items the button is renamed `close`
			JToolBarHelper::cancel( 'cancel', 'Close' );
		}

		$this->assignRef('strategy', $strategy);

		parent::display($tpl);
	}
}