<?php

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * PayoffTable Table class
 *
 */
class TablePayoffTable extends JTable
{
	/**
	 * Primary Key
	 *
	 * @var int
	 */
	var $id_payoff_table = null;
	var $name = null;
	var $description = null;
	var $coop_txt = null;
	var $defe_txt = null;
	var $player_1 = null;
	var $player_2 = null;
	var $player_3 = null;
	var $player_4 = null;
	var $opponent_1 = null;
	var $opponent_2 = null;
	var $opponent_3 = null;
	var $opponent_4 = null;
	
	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function TablePayoffTable(& $db) {
		parent::__construct('#__payofftable', 'id_payoff_table', $db);
	}
}