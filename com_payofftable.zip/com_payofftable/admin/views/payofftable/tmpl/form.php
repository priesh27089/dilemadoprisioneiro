<?php defined('_JEXEC') or die('Restricted access'); ?>

<form action="index.php" method="post" name="adminForm" id="adminForm">
<div class="col100">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'Descrição' ); ?></legend>

		<table class="admintable" style="width:600px;">
		<tr>
			<td width="100px" align="right" class="key">
				<label for="name">
					<?php echo JText::_( 'Nome' ); ?>:
				</label>
			</td>
			<td style="width:400px;">
				<input style="width: 350px;" class="text_area" type="text" name="name" id="name" size="32" maxlength="250" value="<?php echo $this->payofftable->name;?>" />
			</td>
		</tr>
        <tr>
			<td width="100px" align="right" class="key">
				<label for="description">
					<?php echo JText::_( 'Description' ); ?>:
				</label>
			</td>
			<td style="width:400px;">
            	<textarea style="width: 350px;" class="text_area" rows="3" cols="45" id="description" name="description"><?php echo $this->payofftable->description;?></textarea>
			</td>
		</tr>
        <tr>
			<td width="100px" align="right" class="key">
				<label for="description">
					<?php echo JText::_( 'Texto Cooperar' ); ?>:
				</label>
			</td>
			<td style="width:400px;">
            	<input onkeyup="javascript:document.getElementById('player_coop').innerHTML=this.value;document.getElementById('opp_coop').innerHTML=this.value;" style="width: 350px;" class="text_area" type="text" name="coop_txt" id="coop_txt" size="34" maxlength="250" value="<?php echo $this->payofftable->coop_txt;?>" />	
            </td>
		</tr>
        <tr>
			<td width="100px" align="right" class="key">
				<label for="description">
					<?php echo JText::_( 'Texto Não Cooperar' ); ?>:
				</label>
			</td>
			<td style="width:400px;">
            	<input onkeyup="javascript:document.getElementById('player_defe').innerHTML=this.value;document.getElementById('opp_defe').innerHTML=this.value;" style="width: 350px;" class="text_area" type="text" name="defe_txt" id="defe_txt" size="34" maxlength="250" value="<?php echo $this->payofftable->defe_txt;?>" />	
            </td>
		</tr>
        <tr>
			<td width="100px" align="right" class="key">
				<label for="description">
					<?php echo JText::_( 'Ganho C' ); ?>:
				</label>
			</td>
			<td style="width:400px;">
            	<input onkeyup="javascript:document.getElementById('p_3').innerHTML=this.value;document.getElementById('o_2').innerHTML=this.value;javascript:document.getElementById('player_3').value=this.value;document.getElementById('opponent_2').value=this.value;" class="text_area" type="text" name="payoff_c" id="payoff_c" size="34" maxlength="250" value="<?php echo $this->payofftable->player_3;?>" />
            </td>
		</tr>
        <tr>
			<td width="100px" align="right" class="key">
				<label for="description">
					<?php echo JText::_( 'Ganho A' ); ?>:
				</label>
			</td>
			<td style="width:100px;">
            	<input onkeyup="javascript:document.getElementById('p_1').innerHTML=this.value;document.getElementById('o_1').innerHTML=this.value;javascript:document.getElementById('player_1').value=this.value;document.getElementById('opponent_1').value=this.value;" class="text_area" type="text" name="payoff_a" id="payoff_a" size="34" maxlength="250" value="<?php echo $this->payofftable->player_1;?>" />
            </td>
		</tr>
        <tr>
			<td width="100px" align="right" class="key">
				<label for="description">
					<?php echo JText::_( 'Ganho D' ); ?>:
				</label>
			</td>
			<td style="width:100px;">
            	<input onkeyup="javascript:document.getElementById('p_4').innerHTML=this.value;document.getElementById('o_4').innerHTML=this.value;javascript:document.getElementById('player_4').value=this.value;document.getElementById('opponent_4').value=this.value;" class="text_area" type="text" name="payoff_d" id="payoff_d" size="34" maxlength="250" value="<?php echo $this->payofftable->player_4;?>" />
            </td>
		</tr>
        <tr>
			<td width="100px" align="right" class="key">
				<label for="description">
					<?php echo JText::_( 'Ganho B' ); ?>:
				</label>
			</td>
			<td style="width:100px;">
            	<input onkeyup="javascript:document.getElementById('p_2').innerHTML=this.value;document.getElementById('o_3').innerHTML=this.value;javascript:document.getElementById('player_2').value=this.value;document.getElementById('opponent_3').value=this.value;" class="text_area" type="text" name="payoff_b" id="payoff_b" size="34" maxlength="250" value="<?php echo $this->payofftable->player_2;?>" />
            </td>
		</tr>
        <tr>
        
			<td width="10px0" align="right" class="key">
				<label for="description">
					<?php echo JText::_( 'Tabela de Ganhos ' ); ?><p>C > A > D > B</p>
				</label>
			</td>
			<td style="width:400px; height:345px;">
                <div style="width:350px; height:300px; top:0px; left:0px; position:relative;">
                
                    <div style="width:60px; height:120px; position:absolute; top:100px; left:0px; border: solid 2px #000000; text-align:center; padding-top:100px; border-right:none; background:#CCC;">
                        <?php echo JText::_('Jogador'); ?>
                    </div>
                    
                    <div id="player_coop" style="width:60px; height:60px; position:absolute; top:100px; left:60px; border-top: solid 2px #000000; border-bottom: solid 2px #CCCCCC; text-align:center; padding-top:50px; background:#CCC;">
                        <?php echo $this->payofftable->coop_txt ?>
                    </div>
                    
                    <div id="player_defe" style="width:60px; height:60px; position:absolute; top:210px; left:60px; border-bottom: solid 2px #000000; border-top: solid 2px #CCCCCC; text-align:center; padding-top:50px; background:#CCC;">
                        <?php echo $this->payofftable->defe_txt ?>
                    </div>
                    
                    <div style="width:240px; height:25px; position:absolute; top:0px; left:120px; border: solid 2px #000000; text-align:center; padding-top:25px; border-bottom:none; background:#CCC;">
                        <?php echo JText::_('Adversário'); ?>
                    </div>
                    
                    <div id="opp_coop" style="width:120px; height:25px; position:absolute; top:50px; left:120px; border-left: solid 2px #000000; border-right: solid 2px #CCCCCC; padding-top:25px; text-align:center; border-top:none; background:#CCC;">
                        <?php echo $this->payofftable->coop_txt ?>
                    </div>
                    
                    <div id="opp_defe" style="width:120px; height:25px; position:absolute; top:50px; left:240px; border-right: solid 2px #000000; border-left: solid 2px #CCCCCC; padding-top:25px; text-align:center; background:#CCC;">
                        <?php echo $this->payofftable->defe_txt ?>
                    </div>
                
                    <div style="width:100px; height:90px; position:absolute; top:100px; left:120px; border: solid 2px #000000; padding:10px;">
                    <?php echo JText::_('Jogador (A): '); ?>
                    <div id="p_1" style="text-align:left;">
                        <?php echo $this->payofftable->player_1 ?>
                    </div><br />
                    <?php echo JText::_('Adversário (A): '); ?>
                    <div id="o_1" style="text-align:left;">
                        <?php echo $this->payofftable->opponent_1 ?>
                    </div>
              		</div>
                    
                    <div style="width:100px; height:90px; position:absolute; top:100px; left:240px; border: solid 2px #000000; padding:10px;">
                    <?php echo JText::_('Jogador (B): '); ?>
                    <div id="p_2" style="text-align:left;">
                        <?php echo $this->payofftable->player_2 ?>
                    </div><br />
                    <?php echo JText::_('Adversário (C): '); ?>
                    <div id="o_2" style="text-align:left;">
                        <?php echo $this->payofftable->opponent_2 ?>
                    </div>
                    </div>
                    
                    <div style="width:100px; height:90px; position:absolute; top:210px; left:120px; border: solid 2px #000000; padding:10px;">
                    <?php echo JText::_('Jogador (C): '); ?>
                    <div id="p_3" style="text-align:left;">
                        <?php echo $this->payofftable->player_3 ?>
                    </div><br />
                    <?php echo JText::_('Adversário (B): '); ?>
                    <div id="o_3" style="text-align:left;">
                        <?php echo $this->payofftable->opponent_3 ?>
                    </div>
                    </div>
                 
                    <div style="width:100px; height:90px; position:absolute; top:210px; left:240px; border: solid 2px #000000; padding:10px;">
                    <?php echo JText::_('Jogador (D): '); ?>
                    <div id="p_4" style="text-align:left;">
                        <?php echo $this->payofftable->player_4 ?>
                    </div><br />
                    <?php echo JText::_('Adversário (D): '); ?>
                    <div id="o_4" style="text-align:left;">
                        <?php echo $this->payofftable->opponent_4 ?>
                    </div>
                     </div>
                   </div>
			</td>
		</tr>
	</table>
    <input type="hidden" id ="player1" name="player1" value="<? $this->payofftable->player_1 ?>" />
    <input type="hidden" id ="player2" name="player2" value="<? $this->payofftable->player_2 ?>" />
    <input type="hidden" id ="player3" name="player3" value="<? $this->payofftable->player_3 ?>" />
    <input type="hidden" id ="player4" name="player4" value="<? $this->payofftable->player_4 ?>" />
    <input type="hidden" id ="opponent_1" name="opponent_1" value="<? $this->payofftable->opponent_1 ?>" />
    <input type="hidden" id ="opponent_2" name="opponent_2" value="<? $this->payofftable->opponent_2 ?>" />
    <input type="hidden" id ="opponent_3" name="opponent_3" value="<? $this->payofftable->opponent_3 ?>" />
    <input type="hidden" id ="opponent_4" name="opponent_4" value="<? $this->payofftable->opponent_4 ?>" />
	</fieldset>
</div>
<div class="clr"></div>



<input type="hidden" name="option" value="com_payofftable" />
<input type="hidden" name="controller" value="payofftable" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="id_payoff_table" value="<?php echo $this->payofftable->id_payoff_table; ?>" />
</form>
