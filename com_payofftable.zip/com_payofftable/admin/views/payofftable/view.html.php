<?php

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

class PayoffTablesViewPayoffTable extends JView
{
	/**
	 * display method of Payoff Table view
	 * @return void
	 **/
	function display($tpl = null)
	{
		//get the payofftable
		$payofftable		=& $this->get('Data');
		$isNew		= ($payofftable->id_payoff_table < 1);

		$text = $isNew ? JText::_( 'New' ) : JText::_( 'Edit' );
		JToolBarHelper::title(   JText::_( 'Tabela de Ganhos' ).': <small><small>[ ' . $text.' ]</small></small>' , 'generic.png');
		JToolBarHelper::save();
		if ($isNew)  {
			JToolBarHelper::cancel();
		} else {
			// for existing items the button is renamed `close`
			JToolBarHelper::cancel( 'cancel', 'Close' );
		}

		$this->assignRef('payofftable',	$payofftable);

		parent::display($tpl);
	}
}