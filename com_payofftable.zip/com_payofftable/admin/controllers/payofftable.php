<?php

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class payofftablesControllerpayofftable extends payofftablesController
{
	/**
	 * constructor (registers additional tasks to methods)
	 * @return void
	 */
	function __construct()
	{
		parent::__construct();

		// Register Extra tasks
		$this->registerTask( 'add'  , 	'edit' );
	}

	/**
	 * display the edit form
	 * @return void
	 */
	function edit()
	{
		JRequest::setVar( 'view', 'payofftable' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar('hidemainmenu', 1);

		parent::display();
	}

	/**
	 * save a record (and redirect to main page)
	 * @return void
	 */
	function save()
	{
		$payoff_a = JRequest::getVar('payoff_a');
		$payoff_b = JRequest::getVar('payoff_b');
		$payoff_c = JRequest::getVar('payoff_c');
		$payoff_d = JRequest::getVar('payoff_d');
		
		if(is_numeric($payoff_a) && is_numeric($payoff_b) && is_numeric($payoff_c) && is_numeric($payoff_d)){
			JRequest::setVar('player_1', $payoff_a);
			JRequest::setVar('player_2', $payoff_b);
			JRequest::setVar('player_3', $payoff_c);
			JRequest::setVar('player_4', $payoff_d);
			JRequest::setVar('opponent_1', $payoff_a);
			JRequest::setVar('opponent_2', $payoff_c);
			JRequest::setVar('opponent_3', $payoff_b);
			JRequest::setVar('opponent_4', $payoff_d);
			
			if($payoff_c > $payoff_a && $payoff_a > $payoff_d && $payoff_d > $payoff_b){
				$model = $this->getModel('payofftable');
				
				//get data from request
				$post = JRequest::get('post');
		
				if ($model->store($post)) {
					$msg = JText::_( 'Tabela de Ganhos gravada!' );
				} else {
					$msg = JText::_( 'Erro ao gravar a Tabela de Ganhos' );
				}
			}else{
				$msg = JText::_( 'A Tabela de Ganhos não foi gravada. Não foi cumprida a regra C > A > D > B' );
			}
		}else{
			$msg = JText::_( 'Os valores para a Tabela de Ganhos só podem ser numéricos. Volte a tentar de novo.' );
		}
		// Check the table in so it can be edited.... we are done with it anyway
		$link = 'index.php?option=com_payofftable';
		$this->setRedirect($link, $msg);
	}

	/**
	 * remove record(s)
	 * @return void
	 */
	function remove()
	{
		$model = $this->getModel('payofftable');
		if(!$model->delete()) {
			$msg = JText::_( 'Erro: Não foi possível remover uma ou mais tabelas' );
		} else {
			$msg = JText::_( 'Tabela(s) Eliminada' );
		}

		$this->setRedirect( 'index.php?option=com_payofftable', $msg );
	}

	/**
	 * cancel editing a record
	 * @return void
	 */
	function cancel()
	{
		$msg = JText::_( 'Operation Cancelled' );
		$this->setRedirect( 'index.php?option=com_payofftable', $msg );
	}
}