<?php

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Opponent Table class
 *
 */
class TableOpponent extends JTable
{
	/**
	 * Primary Key
	 *
	 * @var int
	 */
	var $id_opponent = null;
	var $name = null;
	var $description = null;
	var $file_name = null;
	var $folder_root = null;
	var $goal = null;

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function TableOpponent(& $db) {
		parent::__construct('#__opponent', 'id_opponent', $db);
	}
}