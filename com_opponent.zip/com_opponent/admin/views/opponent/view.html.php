<?php

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

class OpponentsViewOpponent extends JView
{
	/**
	 * display method of Opponent view
	 * @return void
	 **/
	function display($tpl = null)
	{
		//get the opponent
		$opponent		=& $this->get('Data');
		$isNew		= ($opponent->id_opponent < 1);

		$text = $isNew ? JText::_( 'New' ) : JText::_( 'Edit' );
		JToolBarHelper::title(   JText::_( 'Adversário' ).': <small><small>[ ' . $text.' ]</small></small>' , 'user.png');
		JToolBarHelper::save();
		if ($isNew)  {
			JToolBarHelper::cancel();
		} else {
			// for existing items the button is renamed `close`
			JToolBarHelper::cancel( 'cancel', 'Close' );
		}

		$this->assignRef('opponent', $opponent);

		parent::display($tpl);
	}
}