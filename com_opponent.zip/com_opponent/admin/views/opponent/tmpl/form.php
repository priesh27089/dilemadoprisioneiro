<?php defined('_JEXEC') or die('Restricted access'); ?>

<form action="index.php" method="post" name="adminForm" id="adminForm">
<div class="col100">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'Detalhes' ); ?></legend>

		<table class="admintable">
		<tr>
			<td width="100" align="right" class="key">
				<label for="name">
					<?php echo JText::_( 'Nome' ); ?>:
				</label>
			</td>
			<td>
				<input class="text_area" type="text" name="name" id="name" size="32" maxlength="250" value="<?php echo $this->opponent->name;?>" />
			</td>
		</tr>
        <tr>
			<td width="100" align="right" class="key">
				<label for="description">
					<?php echo JText::_( 'Descrição' ); ?>:
				</label>
			</td>
			<td>
            	<textarea class="text_area" rows="3" cols="45" id="description" name="description"><?php echo $this->opponent->description;?></textarea>
			</td>
		</tr>
        <tr>
			<td width="100" align="right" class="key">
				<label for="folder_root">
					<?php echo JText::_( 'Objectivo' ); ?>:
				</label>
			</td>
			<td>
                <input id="goal" name="goal" type="radio" value="bg_image" <? if($this->opponent->goal == "bg_image") { echo "checked"; } ?>/> <? echo JText::_( "Imagem de Fundo") ?> <br />
			</td>
		</tr>
        <tr>
			<td width="100" align="right" class="key">
				<label for="folder_root">
					<?php echo JText::_( 'Directoria: ' ); ?><br />
                    <?php echo JText::_( 'dentro de Media/stories/' ); ?>
				</label>
			</td>
			<td>
				<input class="text_area" type="text" name="folder_root" id="folder_root" size="32" maxlength="250" value="<?php echo $this->opponent->folder_root;?>" />
			</td>
		</tr>
        <tr>
			<td width="100" align="right" class="key">
				<label for="file_name">
					<?php echo JText::_( 'Ficheiro' ); ?>:
				</label>
			</td>
			<td>
				<input class="text_area" type="text" name="file_name" id="file_name" size="32" maxlength="250" value="<?php echo $this->opponent->file_name;?>" />
			</td>
		</tr>
        <?php /*?>
		<tr>
			<td width="100" align="right" class="key">
				<label for="image">
					<?php echo JText::_( 'Imagem' ); ?>:
				</label>
			</td>
			<td>
			
            <?php
				$directory = 'images/stories/';
				$javascript = "onchange=\"javascript:if (this.value!='') {document.imagelib.src='../$directory' + this.value} else {document.imagelib.src=''}\"";
				echo JHTML::_('list.images', 'image', $active = NULL, $javascript, $directory, $extensions = "bmp|gif|jpg|png"); 
			?>
				<img alt="Opponent Image" name="imagelib" src="../images/stories/<?php echo $this->opponent->image;?>" width="75px" height="75px">
			
			</td>
		</tr>
		<?php */?>
	</table>
	</fieldset>
</div>
<div class="clr"></div>

<input type="hidden" name="option" value="com_opponent" />
<input type="hidden" name="controller" value="opponent" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="id_opponent" value="<?php echo $this->opponent->id_opponent; ?>" />
</form>
