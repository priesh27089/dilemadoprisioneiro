<?php

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Minigamemedia Table class
 *
 */
class TableMinigamemedia extends JTable
{
	var $id_media = null;
	var $file_name = null;
	var $folder_root = null;
	var $goal = null;
	var $id_mini_game = null;

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function TableMinigamemedia(& $db) {
		parent::__construct('#__minigamemedia', 'id_media', $db);
	}
}