<?php defined('_JEXEC') or die('Restricted access'); ?>
<form action="index.php" method="post" name="adminForm">
<div id="editcell">
	<table class="adminlist">
	<thead>
		<tr>
			<th width="5">
				<?php echo JText::_( 'ID' ); ?>
			</th>
			<th width="20">
				<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $this->items ); ?>);" />
			</th>			
			<th>
				<?php echo JText::_( 'Jogo' ); ?>
			</th>
            <th>
				<?php echo JText::_( 'Objectivo' ); ?>
			</th>
		</tr>
	</thead>
	<?php
	$k = 0;
	for ($i=0, $n=count( $this->items ); $i < $n; $i++)	{
		$row = &$this->items[$i];
		$checked 	= JHTML::_('grid.id',   $i, $row->id_media );
		$link 		= JRoute::_( 'index.php?option=com_minigamemedia&controller=minigamemedia&task=edit&cid[]='. $row->id_media );
		?>
		<tr class="<?php echo "row" . $k; ?>">
			<td>
				<?php echo $row->id_media; ?>
			</td>
			<td>
				<?php echo $checked; ?>
			</td>
			<td>
				<a href="<?php echo $link; ?>"><?php echo $row->name; ?></a>
			</td>
            <td>
			<? if($row->goal == "bg_image"){ ?>
					<a href="<?php echo $link; ?>"><? echo JText::_( "Imagem de Fundo") ?></a>
             <? }else if($row->goal == "stars"){ ?>
             		<a href="<?php echo $link; ?>"><? echo JText::_( "Imagem de Pontuação") ?></a>
             <? }else{ ?>
             		<a href="<?php echo $link; ?>"><?php echo $row->goal; ?></a>
             <? } ?>
			</td>
		</tr>
		<?php
		$k = 1 - $k;
	}
	?>
	</table>
</div>

<input type="hidden" name="option" value="com_minigamemedia" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="minigamemedia" />
</form>
