<?php defined('_JEXEC') or die('Restricted access'); ?>

<form action="index.php" method="post" name="adminForm" id="adminForm">
<div class="col100">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'Detalhes' ); ?></legend>

		<table class="admintable">
		<tr>
			<td width="100" align="right" class="key">
				<label for="name">
					<?php echo JText::_( 'Jogo' ); ?>:
				</label>
			</td>
			<td>
            	<? 
				$minigames = JHTML::_('select.genericlist', $this->minigamelist, 'id_mini_game', null,'id_mini_game', 'name', $this->minigamemedia->id_mini_game );
				echo $minigames;
				?>
			</td>
		</tr>
        <tr>
			<td width="100" align="right" class="key">
				<label for="description">
                	<?php echo JText::_( 'Objectivo' ); ?>:
				</label>
			</td>
			<td>
            	<input id="goal" name="goal" type="radio" value="bg_image" <? if($this->minigamemedia->goal == "bg_image") { echo "checked"; } ?>/> <? echo JText::_( "Imagem de Fundo") ?> <br />
            	<input id="goal" name="goal" type="radio" value="stars" <? if($this->minigamemedia->goal == "stars") { echo "checked"; } ?>/> <? echo JText::_( "Imagem de Pontuação (ex: 5 estrelas)") ?> <br />
			</td>
		</tr>
        <tr>
			<td width="100" align="right" class="key">
				<label for="folder_root">
					<?php echo JText::_( 'Directoria: ' ); ?><br />
                    <?php echo JText::_( 'dentro de Media/stories/' ); ?>
				</label>
			</td>
			<td>
				<input class="text_area" type="text" name="folder_root" id="folder_root" size="32" maxlength="250" value="<?php echo $this->minigamemedia->folder_root;?>" />
			</td>
		</tr>
        <tr>
			<td width="100" align="right" class="key">
				<label for="file_name">
					<?php echo JText::_( 'Ficheiro' ); ?>:
				</label>
			</td>
			<td>
				<input class="text_area" type="text" name="file_name" id="file_name" size="32" maxlength="250" value="<?php echo $this->minigamemedia->file_name;?>" />
			</td>
		</tr>
	</table>
	</fieldset>
</div>
<div class="clr"></div>

<input type="hidden" name="option" value="com_minigamemedia" />
<input type="hidden" name="controller" value="minigamemedia" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="id_media" value="<?php echo $this->minigamemedia->id_media; ?>" />
</form>
