<?php

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.view' );

class MinigamemediasViewMinigamemedia extends JView
{
	/**
	 * display method of Minigamemedia view
	 * @return void
	 **/
	function display($tpl = null)
	{
		//get mini games
		$db =& JFactory::getDBO();
		$sql = 'SELECT id_mini_game, name' . ' FROM #__minigame';
      	$db->setQuery($sql);
      	$minigamelist[] = JHTML::_('select.option', '1', '- Selecione um Jogo -', 'id_mini_game', 'name' );
    	$minigamelist = array_merge( $minigamelist, $db->loadObjectList() );
      	//$mini_games = JHTML::_('select.genericlist', $minigamelist, 'id_mini_game', null,'id_mini_game', 'name', 1 );
		
		//get the minigamemedia
		$minigamemedia		=& $this->get('Data');
		$isNew		= ($minigamemedia->id_media < 1);

		$text = $isNew ? JText::_( 'New' ) : JText::_( 'Edit' );
		JToolBarHelper::title(   JText::_( 'Elemento Multimédia de Jogo' ).': <small><small>[ ' . $text.' ]</small></small>' , 'generic.png');
		JToolBarHelper::save();
		if ($isNew)  {
			JToolBarHelper::cancel();
		} else {
			// for existing items the button is renamed `close`
			JToolBarHelper::cancel( 'cancel', 'Close' );
		}

		$this->assignRef('minigamemedia', $minigamemedia);
		//$this->assignRef('themes', $themes);
		$this->assignRef('minigamelist', $minigamelist);

		parent::display($tpl);
	}
}