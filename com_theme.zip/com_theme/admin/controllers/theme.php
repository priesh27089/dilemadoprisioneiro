<?php

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class themesControllertheme extends themesController
{
	/**
	 * constructor (registers additional tasks to methods)
	 * @return void
	 */
	function __construct()
	{
		parent::__construct();

		// Register Extra tasks
		$this->registerTask( 'add'  , 	'edit' );
	}

	/**
	 * display the edit form
	 * @return void
	 */
	function edit()
	{
		JRequest::setVar( 'view', 'theme' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar('hidemainmenu', 1);

		parent::display();
	}

	/**
	 * save a record (and redirect to main page)
	 * @return void
	 */
	function save()
	{
		$model = $this->getModel('theme');
		
		//get data from request
		$post = JRequest::get('post');

		if ($model->store($post)) {
			$msg = JText::_( 'Tema Gravado!' );
		} else {
			$msg = JText::_( 'Erro ao gravar!' );
		}

		// Check the table in so it can be edited.... we are done with it anyway
		$link = 'index.php?option=com_theme';
		$this->setRedirect($link, $msg);
	}

	/**
	 * remove record(s)
	 * @return void
	 */
	function remove()
	{
		$model = $this->getModel('theme');
		if(!$model->delete()) {
			$msg = JText::_( 'Erro: Não foi possível eliminar um ou mais Temas' );
		} else {
			$msg = JText::_( 'Tema(s) removidos' );
		}

		$this->setRedirect( 'index.php?option=com_theme', $msg );
	}

	/**
	 * cancel editing a record
	 * @return void
	 */
	function cancel()
	{
		$msg = JText::_( 'Operação cancelada' );
		$this->setRedirect( 'index.php?option=com_theme', $msg );
	}
}