<?php
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Theme Table class
 */
class TableTheme extends JTable
{
	/**
	 * Primary Key
	 */
	var $id_theme = null;
	var $name = null;
	var $intro_txt = null;
	var $active = null;

	
	/**
	 * Constructor
	 * @param object Database connector object
	 */
	function TableTheme(& $db) {
		parent::__construct('#__theme', 'id_theme', $db);
	}
}